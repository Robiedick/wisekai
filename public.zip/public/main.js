document.addEventListener('DOMContentLoaded', () => {
    console.log('Main JavaScript loaded.');

    function loadMiniApp(appName, containerId) {
        fetch(`/apps/${appName}/${appName}.html`)
            .then(response => response.text())
            .then(htmlContent => {
                const container = document.getElementById(containerId);
                container.innerHTML = htmlContent;

                // Extract and execute scripts from the loaded HTML
                const scripts = container.querySelectorAll('script');
                scripts.forEach(script => {
                    const newScript = document.createElement('script');
                    if (script.src) {
                        newScript.src = script.src;
                    } else {
                        newScript.textContent = script.textContent;
                    }
                    document.body.appendChild(newScript);
                });
            })
            .catch(error => {
                console.error(`Error loading ${appName}:`, error);
                container.innerHTML = `<p>Error loading ${appName}</p>`;
            });
    }

    // Load app1 into the container
    loadMiniApp('app1', 'mini-app-1-container');
});

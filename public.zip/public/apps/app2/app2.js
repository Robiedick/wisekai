function app2Function() {
    alert('Hello from App 2!');
}

function app3Function() {
    alert('Hello from App 3!');
}
